package com.example.weighttracker;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String databaseName = "WeightTracker.db";
    private static final int databaseVersion = 1;

    public DatabaseHelper(Context context) {
        super(context, databaseName, null, databaseVersion);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // might want to hash the password if I publish the app
        String createUsersTable = "CREATE TABLE users (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT, " +
                "password TEXT)";
        db.execSQL(createUsersTable);

        String createWeightTable = "CREATE TABLE weight_entries (" +
                "entry_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER, " +
                "weight REAL, " +
                "date TEXT)";
        db.execSQL(createWeightTable);
        // user id is primary key so each user only have 1 goal.
        String createGoalsTable = "CREATE TABLE goals (" +
                "user_id INTEGER PRIMARY KEY, " +
                "goal_weight REAL)";
        db.execSQL(createGoalsTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS users");
        db.execSQL("DROP TABLE IF EXISTS weight_entries");
        db.execSQL("DROP TABLE IF EXISTS goals");
        onCreate(db);
    }
}