package com.example.weighttracker;

import android.Manifest;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class DataActivity extends AppCompatActivity {

    int currUserId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);

        currUserId = getIntent().getIntExtra("USER_ID", -1);
        loadData();
    }

    public void smsSettingsClicked(View view) {
        Intent intent = new Intent(this, SmsActivity.class);
        startActivity(intent);
    }

    public void addEntryClicked(View view) {
        EditText inputWeight = findViewById(R.id.numberFieldAddEntry);
        String weightText = inputWeight.getText().toString();

        if (weightText.isEmpty()) {
            return;
        }

        // parseWeight is helper, returns -1 if input invalid
        double weight = parseWeight(weightText);
        if (weight <= 0) {
            return;
        }

        // used Locale.getDefault() to fix date to the phones format
        String currDate = new SimpleDateFormat("HH:mm, dd/MM", Locale.getDefault()).format(new Date());

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("user_id", currUserId);
        values.put("weight", weight);
        values.put("date", currDate);

        db.insert("weight_entries", null, values);

        // grab goal to check if new this entry hit it.
        double currGoal = 0;
        Cursor goalCursor = db.rawQuery("SELECT goal_weight FROM goals WHERE user_id = ?", new String[]{String.valueOf(currUserId)});
        if (goalCursor.getCount() > 0) {
            goalCursor.moveToFirst();
            currGoal = goalCursor.getDouble(0);
        }
        goalCursor.close();

        // get starting weight to check loss or gain
        double firstWeight = weight;
        Cursor firstCursor = db.rawQuery("SELECT weight FROM weight_entries WHERE user_id = ? ORDER BY entry_id ASC LIMIT 1", new String[]{String.valueOf(currUserId)});
        if (firstCursor.getCount() > 0) {
            firstCursor.moveToFirst();
            firstWeight = firstCursor.getDouble(0);
        }

        firstCursor.close();
        db.close();

        boolean goalReached = false;
        if (currGoal > 0) {
            if (firstWeight >= currGoal && weight <= currGoal) {
                goalReached = true;
            } else if (firstWeight < currGoal && weight >= currGoal) {
                goalReached = true;
            }
        }

        if (goalReached) {
            SharedPreferences prefs = getSharedPreferences("SmsPrefs", MODE_PRIVATE);
            boolean isSmsEnabled = prefs.getBoolean("sms_enabled", false);
            String phone = prefs.getString("phone_number", "");

            if (isSmsEnabled && !phone.isEmpty()) {
                // make sure permission is on as they could've removed it
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(phone, null, "Goal reached: " + currGoal + "kg!", null, null);
                }
            }
        }

        // clear entry input and update grid
        inputWeight.setText("");
        loadData();
    }

    public void editGoalClicked(View view) {
        EditText inputGoal = findViewById(R.id.numberFieldEditGoal);
        String goalText = inputGoal.getText().toString();

        if (goalText.isEmpty()) {
            return;
        }

        double goal = parseWeight(goalText);
        if (goal <= 0) {
            return;
        }

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("user_id", currUserId);
        values.put("goal_weight", goal);

        // overwrite goal
        db.replace("goals", null, values);
        db.close();

        inputGoal.setText("");
        loadData();
    }

    // rebuilds grid with updated data
    public void loadData() {
        GridLayout gridEntries = findViewById(R.id.gridEntries);
        TextView textProgressWeight = findViewById(R.id.textProgressWeight);
        ProgressBar progressBar = findViewById(R.id.progressBar);

        // clear grid before adding new entries.
        gridEntries.removeAllViews();

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        double currGoal = 0;
        Cursor goalCursor = db.rawQuery("SELECT goal_weight FROM goals WHERE user_id = ?", new String[]{String.valueOf(currUserId)});

        if (goalCursor.getCount() > 0) {
            goalCursor.moveToFirst();
            currGoal = goalCursor.getDouble(0);
        }
        goalCursor.close();


        double firstWeight = 0;
        double latestWeight = 0;

        Cursor weightCursor = db.rawQuery("SELECT entry_id, weight, date FROM weight_entries WHERE user_id = ?", new String[]{String.valueOf(currUserId)});

        while (weightCursor.moveToNext()) {
            int entryId = weightCursor.getInt(0);
            double weight = weightCursor.getDouble(1);
            String date = weightCursor.getString(2);

            // first entry is starting weight
            if (firstWeight == 0) {
                firstWeight = weight;
            }

            // newest is last so the latest weight is the last one in the loop
            latestWeight = weight;

            TextView entryText = new TextView(this);
            entryText.setText(weight + "kg - " + date);
            entryText.setPadding(8, 8, 8, 8);

            Button deleteButton = new Button(this);
            deleteButton.setText("Delete");
            deleteButton.setTextSize(11);
            deleteButton.setMinimumWidth(0);
            deleteButton.setMinimumHeight(0);
            deleteButton.setBackgroundColor(android.graphics.Color.parseColor("#B02A2A"));

            deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    deleteEntry(entryId);
                }
            });

            Button editButton = new Button(this);
            editButton.setText("Edit");
            editButton.setTextSize(11);
            editButton.setMinimumWidth(0);
            editButton.setMinimumHeight(0);
            editButton.setBackgroundColor(android.graphics.Color.parseColor("#5aa329"));

            editButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showEditDialog(entryId, weight);
                }
            });

            // 3 views because each row has 3 cols set in the grid
            gridEntries.addView(entryText);
            gridEntries.addView(editButton);
            gridEntries.addView(deleteButton);
        }

        weightCursor.close();
        db.close();

        textProgressWeight.setText(latestWeight + "kg / " + currGoal + "kg");

        if (currGoal > 0 && latestWeight > 0) {
            int progress;
            if (firstWeight >= currGoal) {
                // weight loss
                progress = (int)((currGoal / latestWeight) * 100);
            } else {
                // weight gain
                progress = (int)((latestWeight / currGoal) * 100);
            }

            // make sure progress can't overflow.
            if (progress > 100) {
                progress = 100;
            }
            progressBar.setProgress(progress);
        }
    }

    // pop up so I don't need a seprate screen for one field.
    public void showEditDialog(int entryId, double oldWeight) {
        EditText inputNewWeight = new EditText(this);
        inputNewWeight.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        inputNewWeight.setText(String.valueOf(oldWeight)); // prefill with old entry

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Entry");
        builder.setView(inputNewWeight);
        builder.setPositiveButton("Save", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String newText = inputNewWeight.getText().toString();
                double newWeight = parseWeight(newText);
                if (newWeight > 0) {
                    updateEntry(entryId, newWeight);
                }
            }
        });
        builder.setNegativeButton("Cancel", null); // null listener closes dialog
        builder.show();
    }

    public void updateEntry(int entryId, double newWeight) {
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("weight", newWeight);

        db.update("weight_entries", values, "entry_id = ?", new String[]{String.valueOf(entryId)});
        db.close();

        loadData();
    }


    public void deleteEntry(int entryId) {
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        db.delete("weight_entries", "entry_id = ?", new String[]{String.valueOf(entryId)});
        db.close();

        loadData();
    }

    // helper to avoid crash if a . is entered instead of a num
    private double parseWeight(String text) {
        try {
            return Double.parseDouble(text);
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}