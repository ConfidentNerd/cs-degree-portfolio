package com.example.weighttracker;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class GoalActivity extends AppCompatActivity {

    int currUserId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_goal);

        currUserId = getIntent().getIntExtra("USER_ID", -1); // -1 is default if not found
    }

    public void saveInitialGoalClicked(View view) {
        EditText inputGoal = findViewById(R.id.inputInitialGoal);
        String goalText = inputGoal.getText().toString();

        if (goalText.isEmpty()) {
            return;
        }

        double goal = parseWeight(goalText);
        if (goal <= 0) {
            return;
        }


        DatabaseHelper dbHelper = new DatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("user_id", currUserId);
        values.put("goal_weight", goal);

        // I only insert the first goal, for the rest I use replace
        db.insert("goals", null, values);
        db.close();

        Intent intent = new Intent(this, DataActivity.class);
        intent.putExtra("USER_ID", currUserId);
        startActivity(intent);
        finish();
    }

    // helper to avoid crash if a . is entered
    private double parseWeight(String text) {
        try {
            return Double.parseDouble(text);
        } catch (NumberFormatException e) {
            return -1;
        }
    }
}