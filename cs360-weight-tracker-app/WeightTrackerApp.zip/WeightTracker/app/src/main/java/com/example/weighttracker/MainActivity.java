package com.example.weighttracker;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.text.TextWatcher;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonSignUp = findViewById(R.id.buttonSignUp);
        EditText inputUsername = findViewById(R.id.inputUsername);
        EditText inputPassword = findViewById(R.id.inputPassword);

        // start buttons disabled
        // (I've already written this logic for module 5 so why not reuse it.)
        buttonLogin.setEnabled(false);
        buttonSignUp.setEnabled(false);

        // create a watcher object to watch for text input
        TextWatcher inputtedTextWatcher = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // not needed.
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // not needed.
            }

            @Override
            public void afterTextChanged(Editable currInput) {
                String username = inputUsername.getText().toString().trim();
                String password = inputPassword.getText().toString();
                boolean areBothFieldsFilled = !username.isEmpty() && !password.isEmpty();

                // if both fields are filled, enable buttons otherwise disable them
                buttonLogin.setEnabled(areBothFieldsFilled);
                buttonSignUp.setEnabled(areBothFieldsFilled);
            }
        };

        // connect watcher to input fields
        inputUsername.addTextChangedListener(inputtedTextWatcher);
        inputPassword.addTextChangedListener(inputtedTextWatcher);
    }

    public void loginClicked(View view) {
        EditText inputUsername = findViewById(R.id.inputUsername);
        EditText inputPassword = findViewById(R.id.inputPassword);
        String username = inputUsername.getText().toString().trim();
        String password = inputPassword.getText().toString();

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT id FROM users WHERE username = ? AND password = ?", new String[]{username, password});

        if (cursor.getCount() > 0) {
            cursor.moveToFirst();
            int userId = cursor.getInt(0);

            Intent intent = new Intent(this, DataActivity.class);
            intent.putExtra("USER_ID", userId);
            startActivity(intent);
            finish(); // so back doesn't take to the login screen
        } else {
            Toast.makeText(this, "Invalid username or password", Toast.LENGTH_SHORT).show();
        }

        cursor.close();
        db.close();
    }

    public void signUpClicked(View view) {
        EditText inputUsername = findViewById(R.id.inputUsername);
        EditText inputPassword = findViewById(R.id.inputPassword);
        String username = inputUsername.getText().toString().trim();
        String password = inputPassword.getText().toString();

        DatabaseHelper dbHelper = new DatabaseHelper(this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        Cursor cursor = db.rawQuery("SELECT id FROM users WHERE username = ?", new String[]{username});

        if (cursor.getCount() > 0) {
            Toast.makeText(this, "Username already exists", Toast.LENGTH_SHORT).show();
            cursor.close();
            db.close();
        } else {
            cursor.close();

            ContentValues values = new ContentValues();
            values.put("username", username);
            values.put("password", password);

            long newUserId = db.insert("users", null, values);

            db.close();

            // new users are sent to the goal screen to set their first goal
            // existing users go straight to the main data screen.
            Intent intent = new Intent(this, GoalActivity.class);
            intent.putExtra("USER_ID", (int) newUserId);
            startActivity(intent);
            finish();
        }
    }
}