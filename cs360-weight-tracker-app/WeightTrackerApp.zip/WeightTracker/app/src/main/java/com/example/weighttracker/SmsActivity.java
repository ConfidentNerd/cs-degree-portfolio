package com.example.weighttracker;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;

public class SmsActivity extends AppCompatActivity {

    int smsPermissionCode = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        Switch switchSms = findViewById(R.id.switchSmsNotifications);
        EditText inputPhone = findViewById(R.id.inputSmsPhone);

        SharedPreferences prefs = getSharedPreferences("SmsPrefs", MODE_PRIVATE);
        switchSms.setChecked(prefs.getBoolean("sms_enabled", false));
        inputPhone.setText(prefs.getString("phone_number", ""));

        switchSms.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    // only ask if switch is turned on, not on app start
                    if (ContextCompat.checkSelfPermission(SmsActivity.this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
                        ActivityCompat.requestPermissions(SmsActivity.this, new String[]{Manifest.permission.SEND_SMS}, smsPermissionCode);
                    } else {
                        saveSettings(true, inputPhone.getText().toString());
                    }
                } else {
                    saveSettings(false, inputPhone.getText().toString());
                }
            }
        });
    }

    public void backClicked(View view) {
        // close current screen to return to previous
        finish();
    }

    // Save settings when the user navigates away. added because otherwise if a num was typed
    // aftert the switch was toggled then it wouldn't get stored.
    @Override
    protected void onPause() {
        super.onPause();

        Switch switchSms = findViewById(R.id.switchSmsNotifications);
        EditText inputPhone = findViewById(R.id.inputSmsPhone);

        boolean hasPermission = ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
        saveSettings(switchSms.isChecked() && hasPermission, inputPhone.getText().toString());
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Switch switchSms = findViewById(R.id.switchSmsNotifications);
        EditText inputPhone = findViewById(R.id.inputSmsPhone);

        if (requestCode == smsPermissionCode) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                saveSettings(true, inputPhone.getText().toString());
            } else {
                // Permission denined so flip switch back to off.
                switchSms.setChecked(false);
                saveSettings(false, inputPhone.getText().toString());
            }
        }
    }

    public void saveSettings(boolean isEnabled, String phone) {
        SharedPreferences prefs = getSharedPreferences("SmsPrefs", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putBoolean("sms_enabled", isEnabled);
        editor.putString("phone_number", phone);
        editor.apply();
    }
}